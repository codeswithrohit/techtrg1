import React, { useRef } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from 'chart.js';
import { FaPrint } from "react-icons/fa";
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

const ADC = ({ maincoursestudents, selectedCourse, selectedYears,selectedMainCourse }) => {
//  console.log("selecteyears",selectedYears)
//  console.log("selectedmaincourse",selectedMainCourse)
    const handlePrint = () => {
        const printableContent = document.getElementById("printableContent");
    
        if (!printableContent) return;
    
        // Convert canvas elements to images
        const chartElements = printableContent.querySelectorAll("canvas");
        
        chartElements.forEach((canvas) => {
            const img = document.createElement("img");
            img.src = canvas.toDataURL("image/png");
            img.style.width = canvas.style.width;
            img.style.height = canvas.style.height;
            canvas.parentNode.replaceChild(img, canvas);
        });
    
        // Hide everything except printable content
        const originalContent = document.body.innerHTML;
        document.body.innerHTML = printableContent.innerHTML;
    
        // Trigger print
        window.print();
    
        // Restore original content
        document.body.innerHTML = originalContent;
        window.location.reload(); // Reload to restore event listeners
    };
    
    
    
    const Data = maincoursestudents.filter(courseData => 
        courseData.course === selectedCourse && 
        (selectedYears.length === 0 || selectedYears.some(year => year.value === courseData.year)) &&
        (selectedMainCourse.length === 0 || selectedMainCourse.some(main => main.value === courseData.maincourse))
    );

    const mergedData = Data.reduce((acc, courseData) => {
        acc.vacAllotted += courseData.vacAllotted || 0;
        acc.vacUtilised += courseData.vacUtilised || 0;

        courseData.students.forEach(student => {
            if (student.grading === "AX(I)") {
                acc.axIStudentsCount += 1;
            } else if (student.grading === "AX") {
                acc.axStudentsCount += 1;
            } else {
                acc.otherStudentsCount += 1;
            }
        });

        return acc;
    }, { vacAllotted: 0, vacUtilised: 0, axIStudentsCount: 0, axStudentsCount: 0, otherStudentsCount: 0 });

    const barChartData = {
        labels: ["Total Vacancies"],
        datasets: [
            {
                label: 'Vacancies Allocated',
                data: [mergedData.vacAllotted],
                backgroundColor: 'rgba(15, 10, 222, 0.7)',
                borderRadius: 8,
                borderWidth: 1,
            },
            {
                label: 'Vacancies Utilized',
                data: [mergedData.vacUtilised],
                backgroundColor: 'rgba(60, 179, 113, 0.7)',
                borderRadius: 8,
                borderWidth: 1,
            }
        ]
    };

    const totalStudents = mergedData.axIStudentsCount + mergedData.axStudentsCount + mergedData.otherStudentsCount;

    const getPercentage = (count) => (totalStudents > 0 ? ((count / totalStudents) * 100).toFixed(1) + '%' : '0%');
    
    const doughnutChartData = {
        labels: [
            `AX(I) (${getPercentage(mergedData.axIStudentsCount)})`,
            `AX (${getPercentage(mergedData.axStudentsCount)})`,
            `Other Graded (${getPercentage(mergedData.otherStudentsCount)})`
        ],
        datasets: [
            {
                label: 'Grading Distribution',
                data: [mergedData.axIStudentsCount, mergedData.axStudentsCount, mergedData.otherStudentsCount],
                backgroundColor: ['rgba(15, 10, 222, 0.7)', 'rgba(60, 179, 113, 0.7)', 'rgba(255, 165, 0, 0.7)'],
                borderWidth: 1,
            }
        ]
    };
    

    return (
        <div className="container mx-auto p-6">
             <div className="flex justify-end my-4">
        <button
          onClick={handlePrint}
          className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 transition flex items-center gap-2"
        >
          <FaPrint />
          Print Report
        </button>
      </div>
      <div id="printableContent">
      <h1 className='font-bold text-white bg-red-800 p-4 font-mono underline text-center text-4xl'>
  SUMMARY OF {selectedYears.map(year => year.label).join(", ")} YR RESULT OF {selectedCourse}
</h1>

            {selectedCourse ? (
                Data.length > 0 ? (
                    <div className="grid md:grid-cols-2 gap-6">
                        {/* Bar Chart */}
                        <div className="bg-white shadow-lg rounded-2xl p-6 hover:shadow-2xl transition-all transform hover:scale-105">
                            <h3 className="text-lg font-semibold mb-4 text-center text-gray-700">Total Vacancies</h3>
                            <Bar data={barChartData} options={{ 
                                responsive: true, 
                                plugins: { 
                                    legend: { position: 'top', labels: { font: { size: 14 } } } 
                                } 
                            }} />
                        </div>
                        
                        {/* Doughnut Chart */}
                        <div className="bg-white shadow-lg rounded-2xl p-6 flex flex-col items-center hover:shadow-2xl transition-all transform hover:scale-105">
                            <h3 className="text-lg font-semibold mb-4 text-center text-gray-700">Grading Distribution</h3>
                            <Doughnut data={doughnutChartData} options={{ 
                                responsive: true, 
                                plugins: { 
                                    legend: { position: 'bottom', labels: { font: { size: 14 } } } 
                                } 
                            }} />
                        </div>
                    </div>
                ) : (
                    <p className="text-center text-gray-500">Loading data...</p>
                )
            ) : (
                <p className="text-center text-gray-500">Please select a course to view data.</p>
            )}
            </div>
        </div>
    );
};

export default ADC;
